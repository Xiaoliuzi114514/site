from flask import Flask, request
import random
import string
import os

app = Flask(__name__)
CODE_FILE = "codes.txt"


def generate_random_code():
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=10))


@app.route("/codes")
def generate_codes():
    codes = {}
    while len(codes) < 100:
        code = generate_random_code()
        codes[str(len(codes)+1) + code] = "0"

    with open(CODE_FILE, "w") as f:
        for code, sid in codes.items():
            f.write(f"{code} {sid}\n")

    html = "<table border='1'>"
    items = list(codes.keys())
    for i in range(0, 100, 5):
        html += "<tr>"
        for j in range(5):
            html += f"<td>{items[i + j]}</td>"
        html += "</tr>"
    html += "</table>"
    return html


@app.route("/signin")
def signin_form():
    return '''
        <form method="post" action="/verify">
            Student ID: <input name="sid"><br>
            Sign-in Code: <input name="code"><br>
            <input type="submit" value="Sign in">
        </form>
    '''


@app.route("/verify", methods=["POST", "GET"])
def verify():
    code = request.values.get("code", "").strip()
    sid = request.values.get("sid", "").strip()

    if not os.path.exists(CODE_FILE):
        return "Codes not generated yet."

    code_map = {}
    with open(CODE_FILE, "r") as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) == 2:
                code_map[parts[0]] = parts[1]

    if code not in code_map:
        return "Wrong code entered"
    elif code_map[code] == "0":
        code_map[code] = sid
        with open(CODE_FILE, "w") as f:
            for k, v in code_map.items():
                f.write(f"{k} {v}\n")
        return "You are successfully signed in"
    elif code_map[code] == sid:
        return "You have signed in already"
    else:
        return f"The code is used by {code_map[code]} and can not be shared"


@app.route("/attended")
def attended():
    if not os.path.exists(CODE_FILE):
        return "Codes not found"

    attended_ids = []
    with open(CODE_FILE, "r") as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) == 2 and parts[1] != "0":
                attended_ids.append(parts[1])
    return "<br>".join(attended_ids)


if __name__ == "__main__":
    app.run(debug=True)